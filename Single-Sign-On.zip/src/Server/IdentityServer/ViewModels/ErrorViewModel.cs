using IdentityServer4.Models;

namespace IdentityServer.ViewModels
{
    /// <summary>
    /// 
    /// </summary>
    public class ErrorViewModel
    {
        /// <summary>
        /// 
        /// </summary>
        public ErrorMessage Error { get; set; }
    }
}