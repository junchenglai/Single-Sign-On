﻿namespace IdentityServer.Models
{
    /// <summary>
    /// 注销输入模板
    /// </summary>
    public class LogoutInputModel
    {
        /// <summary>
        /// 注销申请 ID
        /// </summary>
        public string LogoutId { get; set; }
    }
}
