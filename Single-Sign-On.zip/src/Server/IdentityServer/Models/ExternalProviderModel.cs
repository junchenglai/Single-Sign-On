﻿namespace IdentityServer.ViewModels
{
    /// <summary>
    /// 
    /// </summary>
    public class ExternalProviderModel
    {
        /// <summary>
        /// 
        /// </summary>
        public string DisplayName { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string AuthenticationScheme { get; set; }
    }
}
